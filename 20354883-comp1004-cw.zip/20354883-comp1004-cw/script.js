const databaseURL1 = 'https://qjpizvzvrwixphlvptod.supabase.co';
const APIkey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFqcGl6dnp2cndpeHBobHZwdG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU3NjczNzcsImV4cCI6MjA2MTM0MzM3N30.yYyqpdm0Men81bwMVeeWpoVeT212u129kRHXNDytGUY';

//import { error } from 'console';
// Import the Supabase client
import {createClient} from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

// Initialize the client with your Supabase project URL and API key
const supabase = createClient(databaseURL1, APIkey);

// Call the fetchData function to retrieve data
// document.querySelector('#button1').addEventListener('click'
// , fetchData);

// People search -- accept either name or license
//                  display all search results or error message 
document.addEventListener("DOMContentLoaded", () => {
   const button1 = document.getElementById("peoplesearch");
   if (button1) {  button1.addEventListener("click", searchpeople);  }
});

async function searchpeople() {

   // Obtain values from inputs, message and results sections 
   const nameInput = document.getElementById("name").value.trim();
   const licenseInput = document.getElementById("license").value.trim();
   const messageEl = document.getElementById("message");
   const resultsEl = document.getElementById("results");

   // Clear previous messages and results
   messageEl.innerHTML = "";
   resultsEl.innerHTML = "";

   // Validation
   // Present error message if neither or both of the fields are filled 
   if ((!nameInput && !licenseInput) || (nameInput && licenseInput)) {
      messageEl.innerHTML = `Error: Please only fill in one of the fields`;
      return;
   } 

   let data, error;

   if (nameInput) {
      // Split nameInput into individual keywords
      const keywords = nameInput.split(' ').filter(Boolean);

      // Start the query with the base table
      let query = supabase.from('People').select('*');

      // Add search conditions for each keyword in the nameInput
      keywords.forEach((keyword, index) => {
         if (index === 0) {
            query = query.ilike('Name', `%${keyword}%`);
         } else {
            query = query.or(`Name.ilike.%${keyword}%`);
         }
      });

      // Execute the query
      const result = await query;
      data = result.data;
      error = result.error;

   } else {
      // Search by license number (case-insensitive, partial) from the table People 
      const result = await supabase
         .from('People')
         .select('*')
         .ilike('LicenseNumber', `%${licenseInput}%`);
      
      data = result.data;
      error = result.error;
   }

   // If there is an error, present error message
   if (error) {
      messageEl.textContent = `Error: ${error.message}`;
      return;
   }

   // If there is no matching/relevant data, present message
   if (data.length === 0) {
      messageEl.textContent = `No result found`;
      return;
   }

   // Otherwise, message to indicate a successful search
   messageEl.innerHTML = `Search successful`;

   // For each person, display their name and license
   data.forEach(person => {
      const div = document.createElement("div");
      div.innerHTML = `
      <p>Person ID: ${person.PersonID}
      <br>Name: ${person.Name}
      <br>Address: ${person.Address}
      <br>Date of Birth: ${person.DOB}
      <br>License: ${person.LicenseNumber}
      <br>Expiry Date: ${person.ExpiryDate}</p>`;
      resultsEl.appendChild(div);
   });
}


document.addEventListener("DOMContentLoaded", () => {
   const button2 = document.getElementById("vehiclesearch");
   if (button2) { button2.addEventListener("click", searchvehicle); }
});

async function searchvehicle() {

   // obtain input value, message and results sections 
   const rego = document.getElementById("rego").value.trim();
   const messageEl = document.getElementById("message");
   const resultsEl = document.getElementById("results");

   // clear previous message and results 
   messageEl.innerHTML = "";
   resultsEl.innerHTML = "";

  // validation -- display error message if input field is empty 
   if (!rego) { 
      messageEl.innerHTML = `Error :  empty field`;
      return;
   } 

   let data, error;

   if (rego) {
      // Search by name (case-insensitive, partial) from the table Vehicle 
      ({ data, error } = await supabase
         .from('Vehicle')
         .select('*')
         .ilike('VehicleID', `%${rego}%`) );
   } 

   // display error message if an error occurs
   if (error) {
      messageEl.innerHTML = `Error : ${error.message}`;
      return;
   }

   // if no relevant data is found, display a message 
   if (data.length === 0) {
      messageEl.textContent = "No result found";
      return;
   }

   // otherwise, the search is successful, and display a message 
   messageEl.innerHTML = `Search successful`;

   // for each vehicle, display relevant information 
   data.forEach(Vehicle => {
      const div = document.createElement("div");
      div.innerHTML = `
      <p>Vehicle ID: ${Vehicle.VehicleID}
      <br>Make: ${Vehicle.Make}
      <br>Model: ${Vehicle.Model}
      <br>Colour: ${Vehicle.Colour}
      <br>Owner ID: ${Vehicle.OwnerID}</p>`;
      resultsEl.appendChild(div); 
   });
}

// Add a Vehicle -- accept owner name (+ rego, make, model, colour)
//                   display all search results or error message 
//                   if not found, add new owner
//                   double check if the new owner has not existed in the database already or display error message
//                   if new owner added, add a new vehicle
//                   if no missing info, vehicle added successfully or display error message 

// when chcek owner button is clicked 
document.addEventListener("DOMContentLoaded", () => {
   const button3 = document.getElementById("checkowner");
   if (button3) { button3.addEventListener("click", checkowner); }
});

async function checkowner() {
   const rego = document.getElementById("rego").value.trim();
   const make = document.getElementById("make").value.trim();
   const model = document.getElementById("model").value.trim();
   const colour = document.getElementById("colour").value.trim();
   const owner = document.getElementById("owner").value.trim();
   const messageEl = document.getElementById("message-owner");
   const resultsEl = document.getElementById("owner-results");
   const messageEl2 = document.getElementById("message-vehicle");

   // clear previous message and results 
   messageEl.innerHTML = "";
   resultsEl.innerHTML = "";
   document.getElementById("form2").hidden = true;
    document.getElementById("addavehicle").hidden = true;

   // validation -- only continue if owner name is provided for the search, otherwise present error message 
   if (!owner) { 
      messageEl.innerHTML = `Error : owner name is not provided`;
      return;
   } 

   try {
      // Split nameInput into individual keywords
      const keywords = owner.split(' ').filter(Boolean);

      // Start the query with the base table
      let query = supabase.from('People').select('*');

      // Add search conditions for each keyword in the nameInput
      keywords.forEach((keyword, index) => {
         if (index === 0) {
            query = query.ilike('Name', `%${keyword}%`);
         } else {
            query = query.or(`Name.ilike.%${keyword}%`);
         }
      });

      // Execute the query
      const result = await query;
      const data = result.data;
      const error = result.error;

      // If there's an error, display the error message
      if (error) {
         messageEl.textContent = `Error : ${error.message}`;
         return;
      }

      // If no data is returned, display a "no results" message
      if (data.length === 0) {
         messageEl.textContent = `No result found`;
         //return;
      } else {
           // Otherwise, display the search result message
      messageEl.textContent = `Search successful`;

      // Display the data for each person found
      data.forEach(person => {
         const div = document.createElement("div");
         div.innerHTML = `
            <p>Person ID: ${person.PersonID}
            <br>Name: ${person.Name}
            <br>Address: ${person.Address}
            <br>Date of Birth: ${person.DOB}
            <br>License Number: ${person.LicenseNumber}
            <br>License Expiry Date: ${person.ExpiryDate}</p>`;
         
         const selectowner = document.createElement("button");
         selectowner.innerHTML = `Select owner`;
         div.appendChild(selectowner); 
         resultsEl.appendChild(div); 
         
         // Select owner button functionality
         selectowner.onclick = async () => {
            messageEl.innerHTML = "";
            resultsEl.innerHTML = "";
            messageEl.textContent = `Selected: ${person.Name}`;
            document.getElementById("addavehicle").hidden = false;
            //addvehicle();
         }
      });
      }
  
      const newowner = document.createElement("button");
      newowner.textContent = `New owner`;
      resultsEl.appendChild(newowner); 
      newowner.onclick = () => {
         messageEl.innerHTML = "";
         messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
         messageEl.textContent = `New owner form`;
         document.getElementById("form2").hidden = false;
         const button4 = document.getElementById("addowner");
               button4.onclick = async () => {
                 let personid = document.getElementById("personid").value.trim();
                  const name = document.getElementById("name").value.trim();
                  const address = document.getElementById("address").value.trim();
                  const dob = document.getElementById("dob").value.trim();
                  const license = document.getElementById("license").value.trim();
                  const expire = document.getElementById("expire").value.trim();
                  if (!name ||!address || !dob || !license || !expire) {
                     messageEl.innerHTML = "";
                     resultsEl.innerHTML = "";
                     messageEl.textContent = `Error : missing field(s)`;
                     return;
                  } else if (!/^\d{4}-\d{2}-\d{2}$/.test(dob) || !/^\d{4}-\d{2}-\d{2}$/.test(expire))  {
                          messageEl.innerHTML = "";
                        resultsEl.innerHTML = "";
                        messageEl2.innerHTML = "";
                        messageEl.textContent = `Error : please enter the dates in this format YYYY-MM-DD`;
                        return;

                  } else if (new Date(expire) <= new Date(dob)) {
                      messageEl.innerHTML = "";
                        resultsEl.innerHTML = "";
                        messageEl2.innerHTML = "";
                        messageEl.textContent = `Error : invalid date of birth and license expiry date`;
                        return;

                  } else {
                     //check
                     let licenseUpper = license.toUpperCase();
                     let { data, error } = await supabase
                     .from('People')
                     .select('LicenseNumber')
                     .eq('LicenseNumber', licenseUpper)
                     .limit(1);

                     if (data.length > 0 ) {
                        messageEl.innerHTML = "";
                        resultsEl.innerHTML = "";
                        messageEl2.innerHTML = "";
                        messageEl.textContent = `Error : Invalid license number `;
                        return;
                     } else if (error) {
                        messageEl.innerHTML = "";
                        resultsEl.innerHTML = "";
                        messageEl2.innerHTML = "";
                        messageEl.textContent = `Error : ${error.message}`;
                        return;
                     }

                    // let data, error;
                     ({data, error}  = await supabase
                        .from('People')
                        .select('*')
                        .ilike('Name', `%${name}%`) 
                        .ilike('Address', `%${address}%`) 
                        .ilike('DOB', `%${dob}%`) 
                        // .ilike('DOB', `____-__-__`) 
                        .ilike('LicenseNumber', `%${license}%`) 
                       // .count('LicenseNumber', `%${license}%`)
                        .ilike('ExpiryDate', `%${expire}%`) 
                     )
                     if (error) {
                        messageEl.innerHTML = "";
                        resultsEl.innerHTML = "";
                        messageEl2.innerHTML = "";
                        messageEl.textContent = `Error : ${error.message}`;
                        return;
                     } else if (data.length > 0) {
                        messageEl.innerHTML = "";
                        resultsEl.innerHTML = "";
                        messageEl2.innerHTML = "";
                        messageEl.textContent = `Error : Owner already existed`;
                        return;
                     }
                     
                     if (!personid) {
                        const { data, error } = await supabase
                        .from('People')
                        .select('PersonID')
                        .order('PersonID', { ascending: false }) // Sort descending
                        .limit(1);
                        personid = data[0].PersonID + 1;

                        if (error) {
                           messageEl.innerHTML = "";
                           resultsEl.innerHTML = "";
                           messageEl2.innerHTML = "";
                           messageEl.textContent = `Error : ${error.message}`;
                           return;
                        }
                     }
                     
                     ({ data, error } = await supabase
                       .from('People')
                       .insert([
                         { PersonID: personid,
                           Name: name, 
                           Address: address,
                           DOB: dob,
                           LicenseNumber: license,
                           ExpiryDate: expire }
                       ]) );
         
                       if (error) {
                        messageEl.innerHTML = "";
                        resultsEl.innerHTML = "";
                        messageEl2.innerHTML = "";
                        messageEl.textContent = `Error : ${error.message}`;
                        return;
                     } 
         
                     messageEl.innerHTML = "";
                     messageEl2.innerHTML = "";
                     resultsEl.innerHTML = "";
                     messageEl.textContent = `Owner added successfully`;
                  }
               }
      }

   } catch (err) {
      // Catch any unexpected errors that occur during the process
      messageEl.textContent = `Error : Something went wrong. Please try again later.`;
      console.error(err); // Logs the full error for debugging
      return;
   }
}
 
document.addEventListener("DOMContentLoaded", () => {
   const addvehbut = document.getElementById("addavehicle");
   if (addvehbut) { addvehbut.addEventListener("click", addvehicle); }
});

async function addvehicle() {
   
      const rego = document.getElementById("rego").value.trim();
      const make = document.getElementById("make").value.trim();
      const model = document.getElementById("model").value.trim();
      const colour = document.getElementById("colour").value.trim();
      const owner = document.getElementById("owner").value.trim();
      const messageEl = document.getElementById("message-vehicle");
      const resultsEl = document.getElementById("owner-results");
      const messageEl2 = document.getElementById("message-owner");
      if (!rego || !make || !model || !colour || !owner) {
         messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
         messageEl.textContent = `Error : missing field(s)`;
       //  document.getElementById("addavehicle").hidden = true;
         return;
      } else if (!isNaN(colour)) {
          messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
         messageEl.textContent = `Error : invalid colour`;
         return;
      } else if (!isNaN(make)) {
          messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
         messageEl.textContent = `Error : invalid make`;
         return;
      }
      let data, error;
      let regoUpper = rego.toUpperCase();
     ( {data, error} = await supabase
      .from('Vehicle')
      .select('VehicleID')
      .eq('VehicleID', regoUpper ));

      if (data.length > 0) {
         messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
         messageEl.textContent = `Error : Invalid registration (plate) number`;
         return;
      } else if (error) {
         messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
         messageEl.textContent = `Error : ${error.message}`;
         return;
      }

      const { data: vehicles, error: vehicleError } = await supabase
      .from('Vehicle')
      .select('*')
      .ilike('VehicleID', `%${rego}%`)
      .ilike('Make', `%${make}%`)
      .ilike('Model', `%${model}%`)
      .ilike('Colour', `%${colour}%`);

      const { data: people, error: peopleError } = await supabase
      .from('People')
      .select('*')
      .ilike('Name', `%${owner}%`);
      let personid = people[0].PersonID; 

      const filtered = vehicles
      .filter(vehicle =>
         people.some(person => person.PersonID === vehicle.OwnerID)
      )
      .map(vehicle => ({
         ...vehicle,
         owner: people.find(p => p.PersonID === vehicle.OwnerID)
      }));

      if (vehicleError) {
         messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
         messageEl.innerHTML = `Error : ${vehicleError.message}`;
         return;
      } else if (peopleError) {
         messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
         messageEl.innerHTML = `Error : ${peopleError.message}`;
         return;
      } else if (filtered === 0) {
         messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
         messageEl.innerHTML = `Error : this vehicle has already been added to the owner`;
         return;
      } else {
        const {data, error} = await supabase
         .from('Vehicle')
         .insert([
           { VehicleID: rego,
             Make: make, 
             Model: model,
             Colour: colour,
             OwnerID: personid}
         ]) ;

         if (error) {
            messageEl2.innerHTML = "";
         resultsEl.innerHTML = "";
            messageEl.innerHTML = `Error : ${error.message}`;
            return;
         } else {
            resultsEl.innerHTML = "";
            messageEl2.innerHTML = "";
            messageEl.innerHTML = `Vehicle added successfully`;
            return;
         }
      }

}
