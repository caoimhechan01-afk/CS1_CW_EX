import exp from 'constants';

// @ts-check
const { test, expect} = require('@playwright/test');

// change this to the URL of your website, could be local or GitHub pages
const websiteURL = 'http://127.0.0.1:5500/peoplesearch.html';

// Go to the website home page before each test.
test.beforeEach(async ({ page }) => {
   await page.goto(websiteURL);
});
// set timeout to be 6000ms
test.setTimeout(6000);

// # JavaScript Tests

// // people search

// // // empty fields 
test ('people search -- no input should return error message', async ({page}) => {
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results').locator('div')).toHaveCount(0)
   await expect(page.locator('#message')).toContainText('Error')
})

// // // both fields filled 
test ('people search -- 2 inputs should return error message', async ({page}) => {
   await page.locator('#name').fill('jo')
   await page.locator('#license').fill('KWK24JI')
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results').locator('div')).toHaveCount(0)
   await expect(page.locator('#message')).toContainText('Error')
})

// // // exact driver name 
test ('people search -- search "Rachel Smith" should return SG345PQ and success message', async ({page}) => {
   await page.locator('#name').fill("Rachel Smith")
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('SG345PQ')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)
   await expect(page.locator('#message')).toContainText('Search successful')
})

// // // partial and case insensitive name 
test ('people search -- search "rach smith" should return SG345PQ and success message', async ({page}) => {
   await page.locator('#name').fill("rach smith")
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('SG345PQ')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)
   await expect(page.locator('#message')).toContainText('Search successful')
})

// // // exact license number 
test ('people search -- search "SG345PQ" should return Rachel Smith and success message', async ({page}) => {
   await page.locator('#license').fill("SG345PQ")
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('Rachel Smith')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)
   await expect(page.locator('#message')).toContainText('Search successful')
})

// // // partial and case insensitive license number 
test ('people search -- search "sg34" should return Rachel Smith and success message', async ({page}) => {
   await page.locator('#license').fill("sg34")
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('Rachel Smith')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)
   await expect(page.locator('#message')).toContainText('Search successful')
})

// // // name not existed in table People 
test ('people search -- search "johny" should return no result found', async ({page}) => {
   await page.locator('#name').fill("johny")
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results').locator('div')).toHaveCount(0)
   await expect(page.locator('#message')).toContainText('No result found')
})

// // // license number not existed in table Vehicle 
test ('people search -- search "KS7792" should return no result found', async ({page}) => {
   await page.locator('#license').fill("KS7792")
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results').locator('div')).toHaveCount(0)
   await expect(page.locator('#message')).toContainText('No result found')
})

// // vehicle search

// // // empty field 
test('vehicle search -- no input should return error message', async ({page}) => {
   await page.getByRole('link', { name: 'Vehicle search' }).click();
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results').locator('div')).toHaveCount(0)
   await expect(page.locator('#message')).toContainText('Error')
})

// // // vehicle ID not existed in table Vehicle 
test('search "KS7792" should return no result found', async ({page}) => {
   await page.getByRole('link', { name: 'Vehicle search' }).click();
   await page.locator('#rego').fill('KS7792')
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results').locator('div')).toHaveCount(0)
   await expect(page.locator('#message')).toContainText('No result found')
})

// // // exact vehicle ID 
test('search "GHT56FN" should return Fiat and success message', async ({page}) => {
   await page.getByRole('link', { name: 'Vehicle search' }).click();
   await page.locator('#rego').fill('GHT56FN')
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('Fiat')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)
   await expect(page.locator('#message')).toContainText('Search successful')
})

// // // partial, case insensitive vehicle ID 
test('search "6fN" should return Fiat and success message', async ({page}) => {
   await page.getByRole('link', { name: 'Vehicle search' }).click();
   await page.locator('#rego').fill('6fN')
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('Fiat')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)
   await expect(page.locator('#message')).toContainText('Search successful')
})

// // // partial, case insensitive vehicle ID for multiple vehicles
test('search "F" should return Fiat, Lancia and success message', async ({page}) => {
   await page.getByRole('link', { name: 'Vehicle search' }).click();
   await page.locator('#rego').fill('F')
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('Fiat')
   await expect(page.locator('#results')).toContainText('Lancia')
   await expect(page.locator('#results').locator('div')).toHaveCount(2)
   await expect(page.locator('#message')).toContainText('Search successful')
})

// // Add a Vehicle 

// // // owner not existed, ownerID provided, all valid info for add vehicle 
test('add a vehicle -- add new owner & ID provided to add new vehicle', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#rego').fill('LKJ23UO')
   await page.locator('#make').fill('Porsche')
   await page.locator('#model').fill('Taycan')
   await page.locator('#colour').fill('white')
   await page.locator('#owner').fill('Kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('No result found')
   await expect(page.locator('#results').locator('div')).toHaveCount(0)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#personid').fill('6')
   await page.locator('#name').fill('Kai')
   await page.locator('#address').fill('Edinburgh')
   await page.locator('#dob').fill('1990-01-01')
   await page.locator('#license').fill('SD876ES')
   await page.locator('#expire').fill('2030-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Owner added successfully')

   // people search 
   await page.getByRole('link', { name: 'People search' }).click();
   await page.locator('#name').fill('Kai')
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('SD876ES')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)

   // check owner --> select owner --> add vehicle 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#rego').fill('LKJ23UO')
   await page.locator('#make').fill('Porsche')
   await page.locator('#model').fill('Taycan')
   await page.locator('#colour').fill('white')
   await page.locator('#owner').fill('Kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)
   await page.getByRole('button', { name: 'Select owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Selected: Kai')
   await page.getByRole('button', { name: 'Add vehicle' }).click();
   await expect(page.locator('#message-vehicle')).toContainText('Vehicle added successfully')
   
   // vehicle search 
   await page.getByRole('link', { name: 'Vehicle search' }).click();
   await page.locator('#rego').fill('LKJ23UO')
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('LKJ23UO')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)
})

// // // owner not existed, ownerID not provided, all valid info for add vehicle 
test('add a vehicle -- add new owner & no ID provided to add new vehicle', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#rego').fill('LKJ23U2')
   await page.locator('#make').fill('Porsche')
   await page.locator('#model').fill('Taycan')
   await page.locator('#colour').fill('white')
   await page.locator('#owner').fill('johny')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('No result found')
   await expect(page.locator('#results').locator('div')).toHaveCount(0)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Johny')
   await page.locator('#address').fill('Edinburgh')
   await page.locator('#dob').fill('1990-01-01')
   await page.locator('#license').fill('SD886E2')
   await page.locator('#expire').fill('2030-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Owner added successfully')

   // people search 
   await page.getByRole('link', { name: 'People search' }).click();
   await page.locator('#name').fill('Johny')
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('SD886E2')
   await expect(page.locator('#results')).toContainText('7')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)

   // check owner --> select owner --> add vehicle 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#rego').fill('LKJ23U2')
   await page.locator('#make').fill('Porsche')
   await page.locator('#model').fill('Taycan')
   await page.locator('#colour').fill('white')
   await page.locator('#owner').fill('Johny')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)
   await page.getByRole('button', { name: 'Select owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Selected: Johny')
   await page.getByRole('button', { name: 'Add vehicle' }).click();
   await expect(page.locator('#message-vehicle')).toContainText('Vehicle added successfully')
   
   // vehicle search 
   await page.getByRole('link', { name: 'Vehicle search' }).click();
   await page.locator('#rego').fill('LKJ23U2')
   await page.getByRole('button', { name: 'Submit' }).click();
   await expect(page.locator('#results')).toContainText('LKJ23U2')
   await expect(page.locator('#results')).toContainText('7')
   await expect(page.locator('#results').locator('div')).toHaveCount(1)
})

// // // owner not existed, ownerID not provided, missing info for add vehicle 
test('add a vehicle -- add new owner & missing fields when adding new vehicle', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kaii')
   await page.locator('#address').fill('')
   await page.locator('#dob').fill('1990-01-01')
   await page.locator('#license').fill('')
   await page.locator('#expire').fill('2030-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

// // // owner not existed, ownerID not provided, invalid dob for add vehicle 
test('add a vehicle -- invalid date of birth "01-01-1999" to add owner should return Error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kaii')
   await page.locator('#address').fill('Wollaton')
   await page.locator('#dob').fill('01-01-1999')
   await page.locator('#license').fill('K0234IS')
   await page.locator('#expire').fill('2030-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

// // // owner not existed, ownerID not provided, invalid dob for add vehicle 
test('add a vehicle -- invalid date of birth "dob" should return Error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kaii')
   await page.locator('#address').fill('Wollaton')
   await page.locator('#dob').fill('dob')
   await page.locator('#license').fill('K0234IS')
   await page.locator('#expire').fill('2030-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

// // // owner not existed, ownerID not provided, invalid dob for add vehicle 
test('add a vehicle -- invalid license expiry date "expire" should return Error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kaii')
   await page.locator('#address').fill('Wollaton')
   await page.locator('#dob').fill('2000-01-01')
   await page.locator('#license').fill('K0234IS')
   await page.locator('#expire').fill('expire')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

// // // owner not existed, ownerID not provided, invalid dob for add vehicle 
test('add a vehicle -- invalid license expiry date "20-09-2030" should return Error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kaii')
   await page.locator('#address').fill('Wollaton')
   await page.locator('#dob').fill('2000-01-01')
   await page.locator('#license').fill('K0234IS')
   await page.locator('#expire').fill('20-09-2030')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

/ // // owner not existed, ownerID not provided, invalid dob for add vehicle 
test('add a vehicle -- same date of birth and expiry date should return Error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kaii')
   await page.locator('#address').fill('Wollaton')
   await page.locator('#dob').fill('2000-01-01')
   await page.locator('#license').fill('K0234IS')
   await page.locator('#expire').fill('2000-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

/ // // owner not existed, ownerID not provided, invalid dob for add vehicle 
test('add a vehicle --  date of birth after expiry date should return Error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kaii')
   await page.locator('#address').fill('Wollaton')
   await page.locator('#dob').fill('2010-01-01')
   await page.locator('#license').fill('K0234IS')
   await page.locator('#expire').fill('2000-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

/ // // owner not existed, ownerID not provided, invalid dob for add vehicle 
test('add a vehicle --  existed license number should return Error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('kai')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kaii')
   await page.locator('#address').fill('Wollaton')
   await page.locator('#dob').fill('2000-01-01')
   await page.locator('#license').fill('SG345PQ')
   await page.locator('#expire').fill('2030-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

/ // // owner not existed, ownerID not provided, invalid dob for add vehicle 
test('add a vehicle --  existed, case insensitive license number should return Error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('rach smith')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kaii')
   await page.locator('#address').fill('Wollaton')
   await page.locator('#dob').fill('2000-01-01')
   await page.locator('#license').fill('sg345pq')
   await page.locator('#expire').fill('2030-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

// // // owner not existed, no info for add vehicle 
test('add a vehicle -- add new owner & all empty fields when adding new vehicle', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('rach smith')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner -> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})


// // // all info provided except owner name to check owner 
test('add a vehicle -- owner name not provided to check owner should return error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#rego').fill('LKJ23UO')
   await page.locator('#make').fill('Porsche')
   await page.locator('#model').fill('Taycan')
   await page.locator('#colour').fill('white')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(0)
})

// // // no info provided to check owner 
test('add a vehicle -- no information, including owner name, provided to check owner should return error', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(0)
})

// // // check exact owner name and add an existing owner 
test('add a vehicle -- search "Kai" to check owner and add existing owner should return success and error messages respectively', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('rach smith')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)

   // new owner --> add owner 
   await page.getByRole('button', { name: 'New owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('New owner form')
   await page.locator('#name').fill('Kai')
   await page.locator('#address').fill('Edinburgh')
   await page.locator('#dob').fill('1990-01-01')
   await page.locator('#license').fill('SD876ES')
   await page.locator('#expire').fill('2030-01-01')
   await page.getByRole('button', { name: 'Add owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Error')
})

// // // check partial, case insensitive owner name and add an existing vehicle 
test('add a vehicle -- search "rach smi" to check owner and add existing vehicle should return success and error messages respectively', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#rego').fill('ght56fn')
   await page.locator('#make').fill('fiat')
   await page.locator('#model').fill('punto')
   await page.locator('#colour').fill('blue')
   await page.locator('#owner').fill('rach smi')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)
   await page.getByRole('button', { name: 'Select owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Selected: Rachel Smith')

   // add vehicle
   await page.getByRole('button', { name: 'Add vehicle' }).click();
   await expect(page.locator('#message-vehicle')).toContainText('Error')
})

test('add a vehicle -- search "rach smi" to check and missing field to add vehicle should return success and error messages respectively', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#model').fill('punto')
   await page.locator('#colour').fill('blue')
   await page.locator('#owner').fill('rach smi')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)
   await page.getByRole('button', { name: 'Select owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Selected: Rachel Smith')

   // add vehicle
   await page.getByRole('button', { name: 'Add vehicle' }).click();
   await expect(page.locator('#message-vehicle')).toContainText('Error')
})

test('add a vehicle -- search "rach smi" to check owner and invalid colour to add vehicle should return success and error messages respectively', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#rego').fill('ght56fn')
   await page.locator('#make').fill('fiat')
   await page.locator('#model').fill('punto')
   await page.locator('#colour').fill('123')
   await page.locator('#owner').fill('rach smi')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)
   await page.getByRole('button', { name: 'Select owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Selected: Rachel Smith')

   // add vehicle
   await page.getByRole('button', { name: 'Add vehicle' }).click();
   await expect(page.locator('#message-vehicle')).toContainText('Error')
})

test('add a vehicle -- search "rach smi" to check owner and invalid make to add vehicle should return success and error messages respectively', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#rego').fill('ght56fn')
   await page.locator('#make').fill('123')
   await page.locator('#model').fill('punto')
   await page.locator('#colour').fill('blue')
   await page.locator('#owner').fill('rach smi')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)
   await page.getByRole('button', { name: 'Select owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Selected: Rachel Smith')

   // add vehicle
   await page.getByRole('button', { name: 'Add vehicle' }).click();
   await expect(page.locator('#message-vehicle')).toContainText('Error')
})

test('add a vehicle -- search "rach smi" to check owner and no input to add vehicle should return success and error messages respectively', async ({page}) => {
    // check owner 
   await page.getByRole('link', { name: 'Add a vehicle' }).click();
   await page.locator('#owner').fill('rach smi')
   await page.getByRole('button', { name: 'Check owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Search successful')
   await expect(page.locator('#owner-results').locator('div')).toHaveCount(1)
   await page.getByRole('button', { name: 'Select owner' }).click();
   await expect(page.locator('#message-owner')).toContainText('Selected: Rachel Smith')

   // add vehicle
    await page.locator('#owner').fill('')
   await page.getByRole('button', { name: 'Add vehicle' }).click();
   await expect(page.locator('#message-vehicle')).toContainText('Error')
})